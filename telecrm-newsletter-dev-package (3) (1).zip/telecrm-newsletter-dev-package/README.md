# telecrm monthly feature-update email: how to use this template

This folder is the master for the monthly "What's new" email. Do not redesign it. Each month, copy `template.html`, change only the parts marked EDIT, and send.

## What is in the folder

- `template.html`: the full email with HTML comments marking every block FIXED or EDIT.
- `blocks.html`: spare copies of the two feature blocks and the Beta chip, to paste in as needed.
- `assets/`: all images. The fixed ones (hero background, logos, social icons, the two icons) never change. Feature screenshots and story thumbnails are replaced when marketing sends new ones.

## Fixed every month (do not touch)

- Header: navy hero, arrow background, white logo, orange pill, headline "Use telecrm like a pro". Only the month in the pill changes.
- "⭐ Feature improvements" heading.
- Customer stories section, heading and both stories, unless marketing sends new stories.
- Closing note ("How's telecrm working for your team?" box).
- Footer: purple logo, "The AI-powered platform built to power your business", social icons, address, links.
- Colours, fonts, spacing, widths. Everything is inline-styled on purpose for email clients.

## Changes every month (marketing supplies the text and images)

1. Month in the hero pill, e.g. "What's new · December 2026".
2. Preheader line (the hidden first div): one sentence naming the lead feature.
3. Intro under "Hello there!": two short lines set to the theme of the month. This month's theme was efficiency (getting things done faster). A month with brand-new features or one big launch gets a different intro.
4. The feature blocks between the star heading and the customer stories.

## Choosing feature blocks

- Block A (full width, screenshot): use when there is a UI image for the feature. The screenshot sits in a light panel and runs flush to the panel's bottom edge. Optional "Watch the demo →" link under it.
- Block B (two features side by side, icons, no screenshot): use for smaller improvements with no UI image. Two items per block. Icons available: `icon-code.png`, `icon-file.png`; ask marketing for a new 96px icon (purple glyph on light purple circle) if neither fits.
- Beta chip: paste it after the headline for beta features, remove it when the feature is live for everyone.
- Usual rhythm is three Block A then one Block B. Any mix works. Keep it to six features or fewer.

Headline format is always `Feature name: benefit headline`, with the feature name in purple (already in the markup).

## Image rules

- Feature screenshots: `assets/feature-<name>.jpg`, light theme, 960 to 1200px wide, workspace top bar and avatar cropped out. Marketing sends these ready to use.
- Story thumbnails: `assets/story-<name>.jpg`, 528 x 297 with the play badge, supplied by marketing.
- Everything else in `assets/` is fixed. Never redraw the logo.

## Sending from Brevo

Email clients do not load images from your computer, so every image has to be hosted somewhere public. Two ways:

1. Import the zip. In Brevo go to Templates, Import template, Import from file, and upload a zip that contains `template.html` and the `assets/` folder. Brevo hosts the images and rewrites the paths itself. Easiest option.
2. Upload the images to Brevo's image library (Files), copy each hosted URL and replace `assets/...` in every `src=` and the two `background` references in the hero with those URLs.

Either way, after importing:
- Replace `{{unsubscribe_link}}` with Brevo's own unsubscribe tag (in Brevo's editor it is `{{ unsubscribe }}`).
- Send a test to Gmail, Outlook and a phone. Check the hero background shows, images are not stretched, the two-column block stacks on mobile.
- Keep the HTML under 100 KB. Do not paste base64 images into it; Gmail clips large emails.

Suggested subject: "What's new in telecrm · {Month}". Preheader: the hidden first line in the HTML.

## Writing rules

- "telecrm" is always lowercase.
- British English, no Oxford commas, no em dashes.
- Headlines say the benefit, not the release note.
- Body copy is two or three normal sentences, no exclamation marks.
